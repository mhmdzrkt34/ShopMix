class env {



  String stripePublishableKey="pk_test_51PAWIe06LVWWEteSwzdV1ax2TiXPPWR12C24CfNiRSRsb41YZw1xl6jAflWjNO3kL9ExkJxnoO9sBXQsh1NO6zO8000uS5Dusp";
  String ltcWallet="LRgLesGcRfwjeukgjKL3u8D6vK1zhSW7fa";
  env();
}