import 'package:flutter/material.dart';

class ProfileModelView extends ChangeNotifier {

  ProfileModelView();
}