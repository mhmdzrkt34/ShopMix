import 'package:flutter/material.dart';

class SettingModelView extends ChangeNotifier{


  SettingModelView();
}