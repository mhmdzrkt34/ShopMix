import 'package:flutter/material.dart';

class ShopModelView extends ChangeNotifier {

  ShopModelView();
}