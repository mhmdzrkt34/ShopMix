import 'package:flutter/material.dart';

class RegisterModeView extends ChangeNotifier {

  RegisterModeView();

}