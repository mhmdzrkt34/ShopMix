import 'package:flutter/material.dart';

class LoginModelView extends ChangeNotifier{
  

  LoginModelView();
}