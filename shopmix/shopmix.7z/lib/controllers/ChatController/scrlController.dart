import 'package:flutter/material.dart';

class scrlController {



  final ScrollController scrollController=ScrollController();
  final TextEditingController textformcontroller = TextEditingController();
}