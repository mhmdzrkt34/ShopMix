class ImageSliderModel {



  late String id;


  late String imageUrl;


  ImageSliderModel({required this.id,required this.imageUrl});

  
}