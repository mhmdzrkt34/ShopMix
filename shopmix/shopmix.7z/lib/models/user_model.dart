class UserModel {


  late String id;

  late String Name;

  late String phoneNumber;

  late String Email;

  late String Password;

  late String country;


  UserModel({required this.id,required this.Name,required this.phoneNumber,required this.Email,required this.Password,required this.country});


}