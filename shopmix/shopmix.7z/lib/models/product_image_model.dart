import 'package:shopmix/models/product_model.dart';

class ProductImageModel {

  late String Id;
  late String product_id;

  late String ImageUrl;

  

  ProductImageModel({required this.Id,required this.product_id,required this.ImageUrl});
}