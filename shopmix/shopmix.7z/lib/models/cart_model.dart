class CartModel {


  late String id;
  late String user_id;

  late double total;


  CartModel({required this.id,required this.user_id,required this.total});
}